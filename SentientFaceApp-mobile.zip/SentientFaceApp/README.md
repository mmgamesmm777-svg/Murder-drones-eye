# Sentient Face Engine (Mobile)

Mobilní verze animovaných očí a emocí inspirovaná **Sentient-Eye-Engine** a tvými obrázky.

## Co umí
- Plynulé přechody mezi emocemi (happy → sad → angry atd.)
- Stylizované bílé oči + ústa na černém pozadí (podobné tvým ikonám)
- Efekty: glow, shake, blink, floating hearts/stars, loading spinner
- Ovládání prstem (táhni pro pohled) + tlačítka emocí
- **Připraveno pro vlastní AI**

## Jak spustit na telefonu

### Rychle (doporučeno)
1. Nahraj celou složku `SentientFaceApp` na nějaký hosting (GitHub Pages, Netlify, Vercel, nebo i vlastní server).
2. Otevři `index.html` v prohlížeči telefonu.
3. V prohlížeči → „Přidat na plochu“ / „Add to Home Screen“.
4. Aplikace se chová jako nativní appka (fullscreen, offline-ish).

### Lokálně pro test
```bash
cd SentientFaceApp
python -m http.server 8080
```
Pak otevři na telefonu `http://IP-tvojí-PC:8080`

## Ovládání pro AI

Aplikace vystavuje globální funkce:

```js
// Základní
window.setEmotion("happy");
window.setEmotion("sad", { lookX: 0.3, intensity: 1.2 });
window.lookAt(0.5, -0.2);   // x,y v rozsahu -1..1
window.blink();

// Nebo přes postMessage (ideální pro WebView / iframe)
parent.postMessage({ type: "setEmotion", emotion: "angry" }, "*");
parent.postMessage({ type: "lookAt", x: 0.4, y: 0.1 }, "*");

// Nebo CustomEvent
window.dispatchEvent(new CustomEvent("sentient-command", {
  detail: { emotion: "love", look: { x: 0, y: 0 } }
}));
```

### Podporované emoce
`normal`, `happy`, `sad`, `angry`, `surprised`, `love`, `confused`, `dead`, `loading`

## Klávesové zkratky (desktop)
- `1`–`9` … emoce
- `B` … blink
- `D` … debug panel

## Další rozvoj
- Můžeš přidat vlastní emoce do objektu `emotions` v `face-engine.js`
- Pro plnou nativní appku (Android/iOS) jde snadno zabalit přes Capacitor nebo Cordova
- WebSocket podpora je připravená v komentáři v `app.js`

Vytvořeno jako mobilní nástupce Sentient-Eye-Engine.
Ready for your AI.
