/**
 * App controller – UI + AI bridge
 */

let engine = null;

function init() {
  const canvas = document.getElementById('faceCanvas');
  engine = new FaceEngine(canvas);
  engine.start();

  // Emotion buttons
  document.querySelectorAll('.emotion-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const emo = btn.dataset.emotion;
      setEmotionUI(emo);
    });
  });

  // Keyboard shortcuts
  window.addEventListener('keydown', (e) => {
    const map = {
      '1': 'normal', '2': 'happy', '3': 'sad', '4': 'angry',
      '5': 'surprised', '6': 'love', '7': 'confused', '8': 'dead', '9': 'loading'
    };
    if (map[e.key]) setEmotionUI(map[e.key]);
    if (e.key === 'b') engine.blink();
    if (e.key === 'd') toggleDebug();
  });

  // Touch look-around (drag on canvas)
  let dragging = false;
  canvas.addEventListener('pointerdown', (e) => {
    dragging = true;
    canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    const rect = canvas.getBoundingClientRect();
    const nx = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const ny = ((e.clientY - rect.top) / rect.height) * 2 - 1;
    engine.lookAt(nx * 1.2, ny * 0.9);
  });
  canvas.addEventListener('pointerup', () => { dragging = false; });
  canvas.addEventListener('pointercancel', () => { dragging = false; });

  // Debug panel
  document.getElementById('runCommand').addEventListener('click', runAiCommand);
  document.getElementById('aiCommand').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') runAiCommand();
  });

  // AI / External control bridge
  setupAIBridge();

  // Initial
  setEmotionUI('normal');
  log('Sentient Face Engine ready. AI bridge active.');
}

function setEmotionUI(name) {
  if (!engine) return;
  engine.setEmotion(name);
  document.getElementById('emotionLabel').textContent = name.toUpperCase();

  document.querySelectorAll('.emotion-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.emotion === name);
  });
}

function toggleDebug() {
  document.getElementById('debugPanel').classList.toggle('hidden');
}

function runAiCommand() {
  const input = document.getElementById('aiCommand');
  const cmd = input.value.trim();
  if (!cmd) return;

  try {
    // Support simple calls: setEmotion("happy") or lookAt(0.5, -0.2)
    if (cmd.startsWith('setEmotion')) {
      const match = cmd.match(/setEmotion\s*\(\s*["'](\w+)["']\s*(?:,\s*(\{.*\}))?\s*\)/);
      if (match) {
        const name = match[1];
        let opts = {};
        if (match[2]) opts = JSON.parse(match[2]);
        engine.setEmotion(name, opts);
        setEmotionUI(name);
        log(`AI → setEmotion("${name}")`);
      }
    } else if (cmd.startsWith('lookAt')) {
      const match = cmd.match(/lookAt\s*\(\s*([-\d.]+)\s*,\s*([-\d.]+)\s*\)/);
      if (match) {
        engine.lookAt(parseFloat(match[1]), parseFloat(match[2]));
        log(`AI → lookAt(${match[1]}, ${match[2]})`);
      }
    } else if (cmd === 'blink') {
      engine.blink();
      log('AI → blink()');
    } else {
      // Try eval for advanced (careful in production)
      // eslint-disable-next-line no-eval
      eval(cmd);
      log(`Executed: ${cmd}`);
    }
  } catch (err) {
    log('Error: ' + err.message);
  }
  input.value = '';
}

function log(msg) {
  const el = document.getElementById('log');
  if (el) {
    el.textContent = `[${new Date().toLocaleTimeString()}] ${msg}\n` + el.textContent;
  }
  console.log(msg);
}

/**
 * AI Bridge
 * - window.setEmotion(name, options)
 * - window.lookAt(x, y)
 * - window.blink()
 * - postMessage from parent / WebSocket
 * - CustomEvent 'sentient-command'
 */
function setupAIBridge() {
  // Global functions for easy AI integration
  window.setEmotion = (name, options) => {
    engine.setEmotion(name, options || {});
    setEmotionUI(name);
    document.getElementById('aiStatus').textContent = 'AI ACTIVE';
    log(`External AI → ${name}`);
    return true;
  };

  window.lookAt = (x, y) => engine.lookAt(x, y);
  window.blink = () => engine.blink();
  window.setParams = (p) => engine.setParams(p);

  // postMessage support (for iframe or WebView)
  window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data || typeof data !== 'object') return;

    if (data.type === 'setEmotion' && data.emotion) {
      window.setEmotion(data.emotion, data.options || {});
    } else if (data.type === 'lookAt') {
      window.lookAt(data.x || 0, data.y || 0);
    } else if (data.type === 'blink') {
      window.blink();
    } else if (data.type === 'command' && data.cmd) {
      // generic
      try { eval(data.cmd); } catch (e) { console.warn(e); }
    }
  });

  // Custom event
  window.addEventListener('sentient-command', (e) => {
    const { emotion, look, blink: doBlink, params } = e.detail || {};
    if (emotion) window.setEmotion(emotion);
    if (look) window.lookAt(look.x, look.y);
    if (doBlink) window.blink();
    if (params) window.setParams(params);
  });

  // Example WebSocket (uncomment & set your AI server)
  /*
  const ws = new WebSocket('ws://your-ai-server/face');
  ws.onmessage = (msg) => {
    try {
      const data = JSON.parse(msg.data);
      if (data.emotion) window.setEmotion(data.emotion, data.options);
    } catch (e) {}
  };
  */
}

// Start
document.addEventListener('DOMContentLoaded', init);

// Service worker for PWA (basic)
if ('serviceWorker' in navigator) {
  // Optional: register later
}
