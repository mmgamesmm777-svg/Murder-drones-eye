/**
 * Sentient Face Engine – Mobile / Web
 * Procedural stylized eyes + mouths inspired by the provided icon sets
 * Smooth transitions, effects, ready for AI control
 */

class FaceEngine {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);

    // Current state (interpolated)
    this.state = {
      // Eyes
      eyeOpen: 1.0,          // 0 = closed, 1 = fully open
      eyeWidth: 1.0,
      eyeHeight: 1.0,
      eyeRoundness: 0.85,    // 0 = more rectangular, 1 = round
      pupilScale: 0.55,
      lookX: 0,              // -1 .. 1
      lookY: 0,
      browRaise: 0,          // -1 (down) .. 1 (up)
      browAngle: 0,          // angry tilt
      eyeTilt: 0,            // overall eye rotation
      eyeShape: 'normal',    // normal | happy | sad | angry | surprised | love | dead | x | loading

      // Mouth
      mouthOpen: 0.15,
      mouthWidth: 0.6,
      mouthCurve: 0.3,       // positive = smile, negative = frown
      mouthShape: 'neutral', // neutral | smile | frown | open | heart | o

      // Effects
      glow: 1.0,
      shake: 0,
      blink: 0,              // 0-1 blink progress
      special: null,         // 'hearts' | 'stars' | 'particles' | 'loading' | null
      intensity: 1.0
    };

    // Target state (what we animate towards)
    this.target = JSON.parse(JSON.stringify(this.state));

    // Animation
    this.smooth = 0.12;     // lerp speed
    this.lastTime = performance.now();
    this.particles = [];
    this.symbols = [];      // floating ! ? ♥ ★ etc.
    this.loadingAngle = 0;

    // Emotion presets (based on your images)
    this.emotions = {
      normal: {
        eyeOpen: 1.0, eyeWidth: 1.0, eyeHeight: 1.0, eyeRoundness: 0.9,
        pupilScale: 0.55, browRaise: 0, browAngle: 0, eyeTilt: 0, eyeShape: 'normal',
        mouthOpen: 0.12, mouthWidth: 0.55, mouthCurve: 0.15, mouthShape: 'neutral',
        glow: 1.0, shake: 0, special: null
      },
      happy: {
        eyeOpen: 0.85, eyeWidth: 1.05, eyeHeight: 0.75, eyeRoundness: 0.95,
        pupilScale: 0.5, browRaise: 0.25, browAngle: 0, eyeTilt: 0, eyeShape: 'happy',
        mouthOpen: 0.35, mouthWidth: 0.85, mouthCurve: 0.9, mouthShape: 'smile',
        glow: 1.2, shake: 0, special: null
      },
      sad: {
        eyeOpen: 0.7, eyeWidth: 0.95, eyeHeight: 0.9, eyeRoundness: 0.85,
        pupilScale: 0.6, browRaise: -0.35, browAngle: 0.25, eyeTilt: 0.05, eyeShape: 'sad',
        mouthOpen: 0.18, mouthWidth: 0.5, mouthCurve: -0.75, mouthShape: 'frown',
        glow: 0.75, shake: 0, special: null
      },
      angry: {
        eyeOpen: 0.75, eyeWidth: 1.05, eyeHeight: 0.7, eyeRoundness: 0.7,
        pupilScale: 0.45, browRaise: -0.55, browAngle: -0.55, eyeTilt: -0.08, eyeShape: 'angry',
        mouthOpen: 0.22, mouthWidth: 0.7, mouthCurve: -0.4, mouthShape: 'frown',
        glow: 1.1, shake: 2.5, special: null
      },
      surprised: {
        eyeOpen: 1.15, eyeWidth: 1.1, eyeHeight: 1.2, eyeRoundness: 0.95,
        pupilScale: 0.4, browRaise: 0.6, browAngle: 0, eyeTilt: 0, eyeShape: 'surprised',
        mouthOpen: 0.7, mouthWidth: 0.45, mouthCurve: 0, mouthShape: 'o',
        glow: 1.3, shake: 0, special: null
      },
      love: {
        eyeOpen: 0.9, eyeWidth: 1.0, eyeHeight: 0.95, eyeRoundness: 0.9,
        pupilScale: 0.0, browRaise: 0.15, browAngle: 0, eyeTilt: 0, eyeShape: 'love',
        mouthOpen: 0.25, mouthWidth: 0.7, mouthCurve: 0.7, mouthShape: 'heart',
        glow: 1.4, shake: 0, special: 'hearts'
      },
      confused: {
        eyeOpen: 0.95, eyeWidth: 1.0, eyeHeight: 1.0, eyeRoundness: 0.85,
        pupilScale: 0.5, browRaise: 0.2, browAngle: 0.35, eyeTilt: 0.1, eyeShape: 'normal',
        mouthOpen: 0.2, mouthWidth: 0.4, mouthCurve: 0.1, mouthShape: 'o',
        glow: 1.0, shake: 0, special: null
      },
      dead: {
        eyeOpen: 1.0, eyeWidth: 1.0, eyeHeight: 1.0, eyeRoundness: 0.8,
        pupilScale: 0, browRaise: 0, browAngle: 0, eyeTilt: 0, eyeShape: 'x',
        mouthOpen: 0.15, mouthWidth: 0.5, mouthCurve: -0.2, mouthShape: 'neutral',
        glow: 0.5, shake: 0, special: null
      },
      loading: {
        eyeOpen: 1.0, eyeWidth: 1.0, eyeHeight: 1.0, eyeRoundness: 0.9,
        pupilScale: 0, browRaise: 0, browAngle: 0, eyeTilt: 0, eyeShape: 'loading',
        mouthOpen: 0, mouthWidth: 0, mouthCurve: 0, mouthShape: 'neutral',
        glow: 1.0, shake: 0, special: 'loading'
      }
    };

    this.currentEmotion = 'normal';
    this.resize();
    window.addEventListener('resize', () => this.resize());
  }

  resize() {
    const rect = this.canvas.getBoundingClientRect();
    this.canvas.width = rect.width * this.dpr;
    this.canvas.height = rect.height * this.dpr;
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    this.w = rect.width;
    this.h = rect.height;
    this.cx = this.w / 2;
    this.cy = this.h / 2 - 30; // a bit above center for mobile
  }

  // Public API – call from AI / UI
  setEmotion(name, options = {}) {
    const emo = this.emotions[name];
    if (!emo) {
      console.warn('Unknown emotion:', name);
      return false;
    }
    this.currentEmotion = name;
    Object.assign(this.target, emo);

    // Optional overrides from AI
    if (options.lookX !== undefined) this.target.lookX = options.lookX;
    if (options.lookY !== undefined) this.target.lookY = options.lookY;
    if (options.intensity !== undefined) this.target.intensity = options.intensity;
    if (options.shake !== undefined) this.target.shake = options.shake;

    // Trigger particles for some emotions
    if (name === 'love') this.spawnHearts(8);
    if (name === 'surprised') this.spawnStars(5);

    return true;
  }

  // Direct parameter control (for advanced AI)
  setParams(params) {
    Object.assign(this.target, params);
  }

  lookAt(x, y) {
    // x,y in -1..1
    this.target.lookX = Math.max(-1, Math.min(1, x));
    this.target.lookY = Math.max(-1, Math.min(1, y));
  }

  blink() {
    this.state.blink = 0.01; // start blink
  }

  // --- Animation loop helpers ---
  lerp(a, b, t) {
    return a + (b - a) * t;
  }

  update(dt) {
    const s = this.state;
    const t = this.target;
    const k = 1 - Math.pow(1 - this.smooth, dt * 60); // frame-rate independent

    // Lerp all numeric properties
    for (const key of Object.keys(t)) {
      if (typeof t[key] === 'number' && typeof s[key] === 'number') {
        s[key] = this.lerp(s[key], t[key], k);
      } else if (typeof t[key] === 'string') {
        // Instant switch for discrete shapes (or keep previous until close)
        if (Math.abs(s.eyeOpen - t.eyeOpen) < 0.05) s[key] = t[key];
      }
    }

    // Blink logic
    if (s.blink > 0 && s.blink < 1) {
      s.blink += dt * 8;
      if (s.blink >= 1) s.blink = 0;
    }

    // Auto random look when idle
    if (Math.random() < 0.003) {
      this.target.lookX = (Math.random() - 0.5) * 1.4;
      this.target.lookY = (Math.random() - 0.5) * 0.8;
    }

    // Loading spinner
    if (s.special === 'loading' || s.eyeShape === 'loading') {
      this.loadingAngle += dt * 4;
    }

    // Particles
    this.particles = this.particles.filter(p => {
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 30 * dt; // gravity
      return p.life > 0;
    });

    this.symbols = this.symbols.filter(sym => {
      sym.life -= dt;
      sym.y -= 20 * dt;
      sym.alpha = Math.min(1, sym.life * 2);
      return sym.life > 0;
    });
  }

  spawnHearts(n = 5) {
    for (let i = 0; i < n; i++) {
      this.particles.push({
        type: 'heart',
        x: this.cx + (Math.random() - 0.5) * 120,
        y: this.cy + 40 + Math.random() * 40,
        vx: (Math.random() - 0.5) * 40,
        vy: -40 - Math.random() * 30,
        life: 1.5 + Math.random(),
        size: 10 + Math.random() * 10
      });
    }
  }

  spawnStars(n = 4) {
    for (let i = 0; i < n; i++) {
      this.particles.push({
        type: 'star',
        x: this.cx + (Math.random() - 0.5) * 160,
        y: this.cy + (Math.random() - 0.5) * 100,
        vx: (Math.random() - 0.5) * 60,
        vy: (Math.random() - 0.5) * 40,
        life: 1 + Math.random(),
        size: 8 + Math.random() * 8
      });
    }
  }

  // --- Drawing ---
  draw() {
    const ctx = this.ctx;
    const s = this.state;
    const w = this.w;
    const h = this.h;

    // Clear
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, w, h);

    // Subtle vignette
    const grad = ctx.createRadialGradient(this.cx, this.cy, 50, this.cx, this.cy, Math.max(w, h) * 0.7);
    grad.addColorStop(0, 'rgba(20,10,40,0.3)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // Shake
    const shakeX = (Math.random() - 0.5) * s.shake;
    const shakeY = (Math.random() - 0.5) * s.shake;
    ctx.save();
    ctx.translate(shakeX, shakeY);

    // Glow intensity
    ctx.shadowColor = `rgba(180, 140, 255, ${0.35 * s.glow})`;
    ctx.shadowBlur = 25 * s.glow;

    // Draw eyes
    this.drawEyes(ctx);

    // Draw mouth
    this.drawMouth(ctx);

    // Particles & symbols
    this.drawParticles(ctx);

    ctx.restore();
    ctx.shadowBlur = 0;
  }

  drawEyes(ctx) {
    const s = this.state;
    const eyeDist = 90; // distance between eyes
    const baseSize = Math.min(this.w, this.h) * 0.11;

    const leftX = this.cx - eyeDist;
    const rightX = this.cx + eyeDist;
    const eyeY = this.cy - 20;

    // Blink factor
    let open = s.eyeOpen;
    if (s.blink > 0) {
      const b = s.blink < 0.5 ? s.blink * 2 : (1 - s.blink) * 2;
      open *= (1 - b);
    }

    this.drawSingleEye(ctx, leftX, eyeY, baseSize, open, true);
    this.drawSingleEye(ctx, rightX, eyeY, baseSize, open, false);
  }

  drawSingleEye(ctx, x, y, size, open, isLeft) {
    const s = this.state;
    const lookOffsetX = s.lookX * size * 0.35;
    const lookOffsetY = s.lookY * size * 0.25;

    ctx.save();
    ctx.translate(x + lookOffsetX * 0.3, y + lookOffsetY * 0.3);
    ctx.rotate(s.eyeTilt * (isLeft ? 1 : -1) * 0.3);

    const w = size * s.eyeWidth;
    const h = size * s.eyeHeight * open;

    // Eye shape variations
    if (s.eyeShape === 'x' || s.eyeShape === 'dead') {
      // X eyes
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 6;
      ctx.lineCap = 'round';
      const r = size * 0.55;
      ctx.beginPath();
      ctx.moveTo(-r, -r); ctx.lineTo(r, r);
      ctx.moveTo(r, -r); ctx.lineTo(-r, r);
      ctx.stroke();
    } else if (s.eyeShape === 'love') {
      // Heart eyes
      this.drawHeart(ctx, 0, 0, size * 0.7, '#ff6b9d');
    } else if (s.eyeShape === 'loading') {
      // Loading spinner
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 5;
      ctx.lineCap = 'round';
      for (let i = 0; i < 3; i++) {
        const a = this.loadingAngle + i * (Math.PI * 2 / 3);
        ctx.beginPath();
        ctx.arc(0, 0, size * 0.5, a, a + 0.8);
        ctx.stroke();
      }
    } else {
      // Normal / happy / sad / angry / surprised eyes
      ctx.fillStyle = '#fff';
      ctx.beginPath();

      if (s.eyeShape === 'happy') {
        // Happy: curved upper, flatter lower (like ^ shape inverted)
        const r = w * 0.55;
        ctx.moveTo(-r, 0);
        ctx.quadraticCurveTo(0, -h * 1.1, r, 0);
        ctx.quadraticCurveTo(0, h * 0.4, -r, 0);
      } else if (s.eyeShape === 'angry') {
        // Angry: slanted
        const r = w * 0.5;
        ctx.moveTo(-r * 1.1, -h * 0.3);
        ctx.lineTo(r * 0.9, -h * 0.7);
        ctx.lineTo(r * 0.7, h * 0.5);
        ctx.lineTo(-r * 0.8, h * 0.4);
        ctx.closePath();
      } else if (s.eyeShape === 'sad') {
        // Sad: droopy
        const r = w * 0.5;
        ctx.moveTo(-r, -h * 0.2);
        ctx.quadraticCurveTo(0, -h * 0.6, r, -h * 0.4);
        ctx.quadraticCurveTo(r * 0.6, h * 0.6, 0, h * 0.5);
        ctx.quadraticCurveTo(-r * 0.6, h * 0.5, -r, -h * 0.2);
      } else {
        // Round / oval
        ctx.ellipse(0, 0, w * 0.55, h * 0.55, 0, 0, Math.PI * 2);
      }
      ctx.fill();

      // Pupil (if not special)
      if (s.pupilScale > 0.05 && s.eyeShape !== 'happy') {
        ctx.fillStyle = '#000';
        const px = lookOffsetX * 0.6;
        const py = lookOffsetY * 0.6;
        const pr = size * s.pupilScale * 0.45;
        ctx.beginPath();
        ctx.ellipse(px, py, pr, pr * 1.1, 0, 0, Math.PI * 2);
        ctx.fill();

        // Shine
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        ctx.beginPath();
        ctx.arc(px - pr * 0.3, py - pr * 0.3, pr * 0.25, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Brows (simple lines above eyes)
    if (s.browRaise !== 0 || s.browAngle !== 0) {
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 5;
      ctx.lineCap = 'round';
      const browY = -size * 0.85 + s.browRaise * size * 0.4;
      const ang = s.browAngle * 0.6;
      const len = size * 0.7;

      ctx.beginPath();
      if (isLeft) {
        ctx.moveTo(-len, browY + ang * size * 0.3);
        ctx.lineTo(len * 0.3, browY - ang * size * 0.2);
      } else {
        ctx.moveTo(-len * 0.3, browY - ang * size * 0.2);
        ctx.lineTo(len, browY + ang * size * 0.3);
      }
      ctx.stroke();
    }

    ctx.restore();
  }

  drawMouth(ctx) {
    const s = this.state;
    if (s.mouthOpen < 0.01 && s.mouthShape === 'neutral') return;

    const mx = this.cx + s.lookX * 15;
    const my = this.cy + 95 + s.lookY * 10;
    const mw = 70 * s.mouthWidth;
    const mh = 35 * s.mouthOpen;

    ctx.save();
    ctx.translate(mx, my);
    ctx.fillStyle = '#fff';
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (s.mouthShape === 'heart') {
      this.drawHeart(ctx, 0, 0, 28, '#ff6b9d');
    } else if (s.mouthShape === 'o') {
      ctx.beginPath();
      ctx.ellipse(0, 0, mw * 0.45, mh * 0.9, 0, 0, Math.PI * 2);
      ctx.fill();
    } else if (s.mouthShape === 'smile') {
      ctx.beginPath();
      ctx.moveTo(-mw, -mh * 0.2);
      ctx.quadraticCurveTo(0, mh * 1.4 * s.mouthCurve, mw, -mh * 0.2);
      ctx.stroke();
      // Optional fill for open smile
      if (s.mouthOpen > 0.3) {
        ctx.beginPath();
        ctx.moveTo(-mw * 0.85, 0);
        ctx.quadraticCurveTo(0, mh * 1.6, mw * 0.85, 0);
        ctx.quadraticCurveTo(0, mh * 0.3, -mw * 0.85, 0);
        ctx.fill();
      }
    } else if (s.mouthShape === 'frown') {
      ctx.beginPath();
      ctx.moveTo(-mw, mh * 0.3);
      ctx.quadraticCurveTo(0, -mh * 1.3 * Math.abs(s.mouthCurve), mw, mh * 0.3);
      ctx.stroke();
    } else {
      // Neutral small line / slight curve
      ctx.beginPath();
      ctx.moveTo(-mw * 0.6, 0);
      ctx.quadraticCurveTo(0, mh * s.mouthCurve * 2, mw * 0.6, 0);
      ctx.stroke();
    }

    ctx.restore();
  }

  drawHeart(ctx, x, y, size, color) {
    ctx.save();
    ctx.translate(x, y);
    ctx.fillStyle = color || '#fff';
    ctx.beginPath();
    const s = size / 16;
    ctx.moveTo(0, 4 * s);
    ctx.bezierCurveTo(-8 * s, -6 * s, -16 * s, 2 * s, 0, 14 * s);
    ctx.bezierCurveTo(16 * s, 2 * s, 8 * s, -6 * s, 0, 4 * s);
    ctx.fill();
    ctx.restore();
  }

  drawParticles(ctx) {
    for (const p of this.particles) {
      ctx.globalAlpha = Math.max(0, p.life);
      if (p.type === 'heart') {
        this.drawHeart(ctx, p.x, p.y, p.size, '#ff6b9d');
      } else if (p.type === 'star') {
        ctx.fillStyle = '#fff';
        this.drawStar(ctx, p.x, p.y, p.size);
      }
    }
    ctx.globalAlpha = 1;

    for (const sym of this.symbols) {
      ctx.globalAlpha = sym.alpha;
      ctx.fillStyle = '#fff';
      ctx.font = `bold ${sym.size}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText(sym.char, sym.x, sym.y);
    }
    ctx.globalAlpha = 1;
  }

  drawStar(ctx, x, y, r) {
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const a = (i * 4 * Math.PI) / 5 - Math.PI / 2;
      const px = x + Math.cos(a) * r;
      const py = y + Math.sin(a) * r;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
  }

  // Main loop
  start() {
    const loop = (now) => {
      const dt = Math.min((now - this.lastTime) / 1000, 0.05);
      this.lastTime = now;
      this.update(dt);
      this.draw();
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  }
}

// Export
window.FaceEngine = FaceEngine;
